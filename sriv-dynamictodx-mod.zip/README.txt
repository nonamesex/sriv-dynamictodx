Place default_district.xtbl, default_global.xtbl, skybox_container.asm_pc and skybox_container.str2_pc files in the game directory.

skybox_container contains the SRTT sun texture.
If you install this mod on SRTT, you don't need the skybox_container files.

You will also need to enable dynamic tod in the game itself.
SRTT: Use the Zolika menu (https://zolika1351.pages.dev/mods/sr3menu)
SRIV (legacy): Place dynamic_tod.lua and sr3_city.lua in the game directory.
SRIV (ree): Use MixFix (https://www.saintsrowmods.com/forum/threads/21923/) (Not tested.)
